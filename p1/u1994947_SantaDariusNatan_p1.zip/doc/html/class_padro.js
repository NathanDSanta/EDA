var class_padro =
[
    [ "Padro", "class_padro.html#a1570f530f2c493e4ac8cc8f4910a0c0f", null ],
    [ "estudisEdat", "class_padro.html#a175cbefefea3c0d5798ce142c7469dc2", null ],
    [ "existeixAny", "class_padro.html#a5b9d914c93083f32d935b3512cb2a744", null ],
    [ "llegirDades", "class_padro.html#ac75d33c1e3e722a3f45e7ede2ffb1523", null ],
    [ "mesJoves", "class_padro.html#aa709492625d612ac3968ce08c3cab47e", null ],
    [ "movimentsComunitat", "class_padro.html#aba2ed2ad94a28917ab20f43a5100f42e", null ],
    [ "movimentVells", "class_padro.html#a0d4996420f913cc011b979909c625c86", null ],
    [ "nombreEstudisDistricte", "class_padro.html#a7abf15790e89639d7bbbdb1965a3aea1", null ],
    [ "obtenirNumHabitantsPerAny", "class_padro.html#a59658d3507d7bd123aecc71b146256f0", null ],
    [ "obtenirNumHabitantsPerDistricte", "class_padro.html#a7907328c1f8c9847391ce4152f09ca82", null ],
    [ "obtenirNumHabitantsPerSeccio", "class_padro.html#a655cb85928afe9a416ce324e90ad5028", null ],
    [ "resumEdat", "class_padro.html#aff1712c17752dd8c4019fc8a040bd978", null ],
    [ "resumEstudis", "class_padro.html#a875c51ab7323045e333ccbfcb07c1c45", null ],
    [ "resumNacionalitats", "class_padro.html#abfdea33e54d16d396be0f0f53790f44f", null ],
    [ "resumNivellEstudis", "class_padro.html#a03264959db8614688bdb84969a36c826", null ]
];