var class_persona =
[
    [ "Persona", "class_persona.html#afee9abdfb244d9cc68c7c437c471a920", null ],
    [ "obtenirAnyNaixement", "class_persona.html#a274d0ed5d128c75dac2101a51d2d38c1", null ],
    [ "obtenirCodiPaisNaixement", "class_persona.html#a2d3592c6659d36ef673d59977d757a13", null ],
    [ "obtenirNivellEstudis", "class_persona.html#aaa217107841783839cad7e6de9769597", null ]
];