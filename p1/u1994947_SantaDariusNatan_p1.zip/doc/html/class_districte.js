var class_districte =
[
    [ "Districte", "class_districte.html#a90130914220b5a689c48f54271d0c1df", null ],
    [ "afegir", "class_districte.html#aa5b8f8c43b8247c4bfa06c68b3301d21", null ],
    [ "estudisEdatNacio", "class_districte.html#ac6ce6d62850baf15faa28ec27bba6c21", null ],
    [ "obtenirEdatMitjana", "class_districte.html#ab66aae3b619f62940d7efb9f798b3877", null ],
    [ "obtenirNumHabitants", "class_districte.html#aaef2cc9632a7f78934e77d4f6852e6f9", null ],
    [ "obtenirNumHabitantsEdatEntre", "class_districte.html#abd718e1ff54170a494f06ff922878fc1", null ],
    [ "obtenirNumHabitantsNacio", "class_districte.html#aab27f78ad313204fe935db94a496fe8f", null ],
    [ "obtenirNumHabitantsPerSeccio", "class_districte.html#ae203af009d74c0388d1a8e93304b83f8", null ],
    [ "obtenirPromigNivellEstudis", "class_districte.html#a27cdeb8c0bbdce60c016178d726e9d25", null ],
    [ "resumEstudis", "class_districte.html#a029f424f2919437d098a8848c98bc7ae", null ],
    [ "resumNacionalitats", "class_districte.html#a50f8608115a299892606bf18a61fa763", null ]
];