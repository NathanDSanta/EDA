var class_estudi =
[
    [ "Estudi", "class_estudi.html#af993a9482363c394babde738ec6660ee", null ],
    [ "obtenirId", "class_estudi.html#a7a7ae02d49fe987c81e77fcb141f7ff4", null ],
    [ "obtenirNom", "class_estudi.html#ae0418b107b8667580d8cd32340253f1e", null ],
    [ "operator<", "class_estudi.html#aeb667f9deefab9e47962a5b95ef9dd6a", null ],
    [ "operator==", "class_estudi.html#ac14ede96d7e6569b2d48df2c20946bcd", null ]
];