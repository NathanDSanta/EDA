var _resum_nacionalitats_8h =
[
    [ "ResumNacionalitats", "class_resum_nacionalitats.html", null ]
];