var _resum_edats_8h =
[
    [ "ResumEdats", "class_resum_edats.html", null ]
];