var _districte_8h =
[
    [ "Districte", "class_districte.html", "class_districte" ]
];