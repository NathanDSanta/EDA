var annotated_dup =
[
    [ "Any", "class_any.html", "class_any" ],
    [ "Districte", "class_districte.html", "class_districte" ],
    [ "Estudi", "class_estudi.html", "class_estudi" ],
    [ "Nacionalitat", "class_nacionalitat.html", "class_nacionalitat" ],
    [ "Padro", "class_padro.html", "class_padro" ],
    [ "Persona", "class_persona.html", "class_persona" ],
    [ "ResumEdats", "class_resum_edats.html", null ],
    [ "ResumEstudis", "class_resum_estudis.html", null ],
    [ "ResumNacionalitats", "class_resum_nacionalitats.html", null ],
    [ "ResumNivellEstudis", "class_resum_nivell_estudis.html", null ],
    [ "Seccio", "class_seccio.html", "class_seccio" ]
];