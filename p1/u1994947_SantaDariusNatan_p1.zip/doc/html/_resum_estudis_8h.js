var _resum_estudis_8h =
[
    [ "ResumEstudis", "class_resum_estudis.html", null ]
];