var searchData=
[
  ['afegir_0',['afegir',['../class_any.html#a0b2f72b29fae1727ecd1155a68efabaa',1,'Any::afegir()'],['../class_districte.html#aa5b8f8c43b8247c4bfa06c68b3301d21',1,'Districte::afegir()'],['../class_seccio.html#a95f4cf3b67ad5a18863023b7338ab499',1,'Seccio::afegir()']]],
  ['any_1',['Any',['../class_any.html#a61695ce16b189cde218eed7c06f63cf8',1,'Any']]]
];
