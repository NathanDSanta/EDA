var searchData=
[
  ['nacionalitat_0',['Nacionalitat',['../class_nacionalitat.html',1,'']]]
];
