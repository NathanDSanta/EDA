var searchData=
[
  ['districte_0',['Districte',['../class_districte.html',1,'']]]
];
