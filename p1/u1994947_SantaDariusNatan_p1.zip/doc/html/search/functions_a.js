var searchData=
[
  ['seccio_0',['Seccio',['../class_seccio.html#ab7ec1e00459326dd4cf630ed1c6743a5',1,'Seccio']]]
];
