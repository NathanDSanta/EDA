var searchData=
[
  ['demanar_5fint_0',['demanar_int',['../main_8cpp.html#af72c1f7c7acfee7324ca00343ec0e273',1,'main.cpp']]],
  ['demanar_5fstring_1',['demanar_string',['../main_8cpp.html#a84c3305666b669ff592fae0990d4f796',1,'main.cpp']]],
  ['districte_2',['Districte',['../class_districte.html#a90130914220b5a689c48f54271d0c1df',1,'Districte']]]
];
