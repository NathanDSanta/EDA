var searchData=
[
  ['n_5fdistrictes_0',['N_DISTRICTES',['../class_any.html#aeddd489049071f09ac7b953c97236923',1,'Any']]],
  ['nacionalitat_1',['Nacionalitat',['../class_nacionalitat.html',1,'Nacionalitat'],['../class_nacionalitat.html#a9c48dcd60fa8437ddd13d063c862411d',1,'Nacionalitat::Nacionalitat()']]],
  ['nacionalitat_2ecpp_2',['Nacionalitat.cpp',['../_nacionalitat_8cpp.html',1,'']]],
  ['nacionalitat_2eh_3',['Nacionalitat.h',['../_nacionalitat_8h.html',1,'']]],
  ['nombreestudisdistricte_4',['nombreEstudisDistricte',['../class_padro.html#a7abf15790e89639d7bbbdb1965a3aea1',1,'Padro']]]
];
