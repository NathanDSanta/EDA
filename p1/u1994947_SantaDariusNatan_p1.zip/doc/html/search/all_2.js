var searchData=
[
  ['demanar_5fint_0',['demanar_int',['../main_8cpp.html#af72c1f7c7acfee7324ca00343ec0e273',1,'main.cpp']]],
  ['demanar_5fstring_1',['demanar_string',['../main_8cpp.html#a84c3305666b669ff592fae0990d4f796',1,'main.cpp']]],
  ['districte_2',['Districte',['../class_districte.html',1,'Districte'],['../class_districte.html#a90130914220b5a689c48f54271d0c1df',1,'Districte::Districte()']]],
  ['districte_2ecpp_3',['Districte.cpp',['../_districte_8cpp.html',1,'']]],
  ['districte_2eh_4',['Districte.h',['../_districte_8h.html',1,'']]],
  ['districtes_5',['DISTRICTES',['../class_any.html#a5836f920f5f64f15bbf78d194869166d',1,'Any']]]
];
