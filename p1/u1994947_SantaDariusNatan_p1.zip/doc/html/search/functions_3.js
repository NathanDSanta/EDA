var searchData=
[
  ['error_0',['error',['../mostra_8cpp.html#a9cf0cc44cbe4eb1b7080b7b8b9cebd34',1,'error(const string &amp;missatge):&#160;mostra.cpp'],['../mostra_8h.html#a9cf0cc44cbe4eb1b7080b7b8b9cebd34',1,'error(const string &amp;missatge):&#160;mostra.cpp']]],
  ['estudi_1',['Estudi',['../class_estudi.html#af993a9482363c394babde738ec6660ee',1,'Estudi']]],
  ['estudisedat_2',['estudisEdat',['../class_padro.html#a175cbefefea3c0d5798ce142c7469dc2',1,'Padro']]],
  ['estudisedatnacio_3',['estudisEdatNacio',['../class_any.html#a559a1ffba7a3d4369c80d96ae35f0798',1,'Any::estudisEdatNacio()'],['../class_districte.html#ac6ce6d62850baf15faa28ec27bba6c21',1,'Districte::estudisEdatNacio()'],['../class_seccio.html#a2b4cb0fd1b2ef921e0492b01c52ef2f8',1,'Seccio::estudisEdatNacio()']]],
  ['existeixany_4',['existeixAny',['../class_padro.html#a5b9d914c93083f32d935b3512cb2a744',1,'Padro']]]
];
