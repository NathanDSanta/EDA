var searchData=
[
  ['seccio_0',['Seccio',['../class_seccio.html',1,'Seccio'],['../class_seccio.html#ab7ec1e00459326dd4cf630ed1c6743a5',1,'Seccio::Seccio()']]],
  ['seccio_2ecpp_1',['Seccio.cpp',['../_seccio_8cpp.html',1,'']]],
  ['seccio_2eh_2',['Seccio.h',['../_seccio_8h.html',1,'']]]
];
