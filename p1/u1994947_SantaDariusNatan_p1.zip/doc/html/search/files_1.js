var searchData=
[
  ['districte_2ecpp_0',['Districte.cpp',['../_districte_8cpp.html',1,'']]],
  ['districte_2eh_1',['Districte.h',['../_districte_8h.html',1,'']]]
];
