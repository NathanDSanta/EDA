var searchData=
[
  ['padro_0',['Padro',['../class_padro.html#a1570f530f2c493e4ac8cc8f4910a0c0f',1,'Padro']]],
  ['persona_1',['Persona',['../class_persona.html#afee9abdfb244d9cc68c7c437c471a920',1,'Persona']]],
  ['poblaciojovesdistricte_2',['poblacioJovesDistricte',['../class_any.html#a1317561eae18fe80c65e1e5eb4747208',1,'Any']]]
];
