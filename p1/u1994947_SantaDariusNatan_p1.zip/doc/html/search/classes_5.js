var searchData=
[
  ['resumedats_0',['ResumEdats',['../class_resum_edats.html',1,'']]],
  ['resumestudis_1',['ResumEstudis',['../class_resum_estudis.html',1,'']]],
  ['resumnacionalitats_2',['ResumNacionalitats',['../class_resum_nacionalitats.html',1,'']]],
  ['resumnivellestudis_3',['ResumNivellEstudis',['../class_resum_nivell_estudis.html',1,'']]]
];
