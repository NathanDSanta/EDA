var searchData=
[
  ['nacionalitat_0',['Nacionalitat',['../class_nacionalitat.html#a9c48dcd60fa8437ddd13d063c862411d',1,'Nacionalitat']]],
  ['nombreestudisdistricte_1',['nombreEstudisDistricte',['../class_padro.html#a7abf15790e89639d7bbbdb1965a3aea1',1,'Padro']]]
];
