var searchData=
[
  ['banner_0',['banner',['../mostra_8cpp.html#a5cd76f42ddc88684fbff112a9c5e5e51',1,'banner(const int &amp;opcio):&#160;mostra.cpp'],['../mostra_8h.html#a5cd76f42ddc88684fbff112a9c5e5e51',1,'banner(const int &amp;opcio):&#160;mostra.cpp']]]
];
