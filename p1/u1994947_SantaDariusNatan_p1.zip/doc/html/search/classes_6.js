var searchData=
[
  ['seccio_0',['Seccio',['../class_seccio.html',1,'']]]
];
