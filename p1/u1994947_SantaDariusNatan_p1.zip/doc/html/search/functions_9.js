var searchData=
[
  ['resumedat_0',['resumEdat',['../class_padro.html#aff1712c17752dd8c4019fc8a040bd978',1,'Padro']]],
  ['resumestudis_1',['resumEstudis',['../class_any.html#a83019645f154eef24600dec30e190512',1,'Any::resumEstudis()'],['../class_districte.html#a029f424f2919437d098a8848c98bc7ae',1,'Districte::resumEstudis()'],['../class_padro.html#a875c51ab7323045e333ccbfcb07c1c45',1,'Padro::resumEstudis()']]],
  ['resumnacionalitats_2',['resumNacionalitats',['../class_any.html#a026aeaad3695d8f3be28ae0b7ab6256b',1,'Any::resumNacionalitats()'],['../class_districte.html#a50f8608115a299892606bf18a61fa763',1,'Districte::resumNacionalitats()'],['../class_padro.html#abfdea33e54d16d396be0f0f53790f44f',1,'Padro::resumNacionalitats()']]],
  ['resumnivellestudis_3',['resumNivellEstudis',['../class_any.html#a736951f85574d6004afbe4b4e044f07a',1,'Any::resumNivellEstudis()'],['../class_padro.html#a03264959db8614688bdb84969a36c826',1,'Padro::resumNivellEstudis()']]]
];
