var searchData=
[
  ['llegirdades_0',['llegirDades',['../class_padro.html#ac75d33c1e3e722a3f45e7ede2ffb1523',1,'Padro']]]
];
