var searchData=
[
  ['eines_2ecpp_0',['eines.cpp',['../eines_8cpp.html',1,'']]],
  ['eines_2eh_1',['eines.h',['../eines_8h.html',1,'']]],
  ['error_2',['error',['../mostra_8cpp.html#a9cf0cc44cbe4eb1b7080b7b8b9cebd34',1,'error(const string &amp;missatge):&#160;mostra.cpp'],['../mostra_8h.html#a9cf0cc44cbe4eb1b7080b7b8b9cebd34',1,'error(const string &amp;missatge):&#160;mostra.cpp']]],
  ['estudi_3',['Estudi',['../class_estudi.html',1,'Estudi'],['../class_estudi.html#af993a9482363c394babde738ec6660ee',1,'Estudi::Estudi()']]],
  ['estudi_2ecpp_4',['Estudi.cpp',['../_estudi_8cpp.html',1,'']]],
  ['estudi_2eh_5',['Estudi.h',['../_estudi_8h.html',1,'']]],
  ['estudisedat_6',['estudisEdat',['../class_padro.html#a175cbefefea3c0d5798ce142c7469dc2',1,'Padro']]],
  ['estudisedatnacio_7',['estudisEdatNacio',['../class_any.html#a559a1ffba7a3d4369c80d96ae35f0798',1,'Any::estudisEdatNacio()'],['../class_districte.html#ac6ce6d62850baf15faa28ec27bba6c21',1,'Districte::estudisEdatNacio()'],['../class_seccio.html#a2b4cb0fd1b2ef921e0492b01c52ef2f8',1,'Seccio::estudisEdatNacio()']]],
  ['existeixany_8',['existeixAny',['../class_padro.html#a5b9d914c93083f32d935b3512cb2a744',1,'Padro']]]
];
