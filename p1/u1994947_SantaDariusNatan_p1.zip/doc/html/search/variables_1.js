var searchData=
[
  ['n_5fdistrictes_0',['N_DISTRICTES',['../class_any.html#aeddd489049071f09ac7b953c97236923',1,'Any']]]
];
