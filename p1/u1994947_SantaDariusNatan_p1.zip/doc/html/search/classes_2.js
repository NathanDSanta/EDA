var searchData=
[
  ['estudi_0',['Estudi',['../class_estudi.html',1,'']]]
];
