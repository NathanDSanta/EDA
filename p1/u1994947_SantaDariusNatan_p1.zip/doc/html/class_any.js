var class_any =
[
    [ "Any", "class_any.html#a61695ce16b189cde218eed7c06f63cf8", null ],
    [ "afegir", "class_any.html#a0b2f72b29fae1727ecd1155a68efabaa", null ],
    [ "estudisEdatNacio", "class_any.html#a559a1ffba7a3d4369c80d96ae35f0798", null ],
    [ "movimentsComunitat", "class_any.html#a962e1c449786c32b625b0eff9d0cb3ef", null ],
    [ "movimentVells", "class_any.html#af41a4db82444d374c634b1509342c679", null ],
    [ "obtenirEdatsMitjanes", "class_any.html#a335c18164407746987206f99956ed590", null ],
    [ "obtenirNumHabitants", "class_any.html#a353c3ac26cfbff39cffcd1c0bd87d277", null ],
    [ "obtenirNumHabitantsPerDistricte", "class_any.html#a44257b25797d2fac17a0ac7b3545b605", null ],
    [ "obtenirNumHabitantsPerSeccio", "class_any.html#a7cdd86ebeec19b5b1e2a66308e02658f", null ],
    [ "poblacioJovesDistricte", "class_any.html#a1317561eae18fe80c65e1e5eb4747208", null ],
    [ "resumEstudis", "class_any.html#a83019645f154eef24600dec30e190512", null ],
    [ "resumNacionalitats", "class_any.html#a026aeaad3695d8f3be28ae0b7ab6256b", null ],
    [ "resumNivellEstudis", "class_any.html#a736951f85574d6004afbe4b4e044f07a", null ]
];