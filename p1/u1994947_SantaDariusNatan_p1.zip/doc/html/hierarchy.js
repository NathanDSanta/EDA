var hierarchy =
[
    [ "Any", "class_any.html", null ],
    [ "Districte", "class_districte.html", null ],
    [ "Estudi", "class_estudi.html", null ],
    [ "std::map", null, [
      [ "ResumEdats", "class_resum_edats.html", null ],
      [ "ResumEstudis", "class_resum_estudis.html", null ],
      [ "ResumNacionalitats", "class_resum_nacionalitats.html", null ],
      [ "ResumNivellEstudis", "class_resum_nivell_estudis.html", null ]
    ] ],
    [ "Nacionalitat", "class_nacionalitat.html", null ],
    [ "Padro", "class_padro.html", null ],
    [ "Persona", "class_persona.html", null ],
    [ "Seccio", "class_seccio.html", null ]
];