var class_nacionalitat =
[
    [ "Nacionalitat", "class_nacionalitat.html#a9c48dcd60fa8437ddd13d063c862411d", null ],
    [ "obtenirId", "class_nacionalitat.html#ad6b20a84453e176f3880e46a0923ac03", null ],
    [ "obtenirNom", "class_nacionalitat.html#af250dcafe670bef93b37a933d05e0a29", null ],
    [ "operator<", "class_nacionalitat.html#a7b0ba778d0c1069d41cc667a961bcaeb", null ],
    [ "operator==", "class_nacionalitat.html#a174532d462c4f20e184198aa4b305a5a", null ]
];