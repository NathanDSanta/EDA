var _estudi_8h =
[
    [ "Estudi", "class_estudi.html", "class_estudi" ]
];