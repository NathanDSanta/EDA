var class_seccio =
[
    [ "Seccio", "class_seccio.html#ab7ec1e00459326dd4cf630ed1c6743a5", null ],
    [ "afegir", "class_seccio.html#a95f4cf3b67ad5a18863023b7338ab499", null ],
    [ "estudisEdatNacio", "class_seccio.html#a2b4cb0fd1b2ef921e0492b01c52ef2f8", null ],
    [ "obtenirNumHabitants", "class_seccio.html#aa68b5399ff68320097ffe6c5c81c4510", null ],
    [ "obtenirNumHabitantsEdatEntre", "class_seccio.html#a1cbeb7ec0646852bd1932106e0eeeedf", null ]
];