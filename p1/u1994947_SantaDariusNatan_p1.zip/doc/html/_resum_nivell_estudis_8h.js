var _resum_nivell_estudis_8h =
[
    [ "ResumNivellEstudis", "class_resum_nivell_estudis.html", null ]
];