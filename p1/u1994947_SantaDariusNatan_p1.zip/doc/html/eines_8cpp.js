var eines_8cpp =
[
    [ "token", "eines_8cpp.html#aa9cc83610105486fab4a21343e5dccc5", null ],
    [ "tokens", "eines_8cpp.html#ac386a3def60373b4661b397131f3c9fc", null ]
];