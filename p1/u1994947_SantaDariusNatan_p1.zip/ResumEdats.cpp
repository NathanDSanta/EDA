#include "ResumEdats.h"

#include <map>
#include <string>
#include <vector>

template class std::vector<std::map<double, std::string>>;
