
Funcionen tots els mètodes proposats

l'arxiu **script_compilacio** proporciona totes les comandes per a la compilació,
execució (+ mostra temps d'aquest) i mostra les diferències amb els arxius
proporcionats.

Hi ha una classe Seccio, que es podria ometre, però manté les funcions
lleugerament més organitzades.

També m'agradaria comentar que podria passar per referència diversos vectors 
i estructures, però al no tenir problemes de memòria, no ho he considerat
absolutament necessaris.
