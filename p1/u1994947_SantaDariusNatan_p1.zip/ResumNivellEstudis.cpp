#include "ResumNivellEstudis.h"

#include <map>
#include <utility>

template class std::map<int, std::map<int, std::pair<double, int>>>;
