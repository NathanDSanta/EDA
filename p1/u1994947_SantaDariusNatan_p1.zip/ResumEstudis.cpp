#include "ResumEstudis.h"

#include <map>
#include <string>

template class std::map<int, std::string>;
